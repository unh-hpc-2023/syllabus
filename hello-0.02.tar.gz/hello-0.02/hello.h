
#ifndef HELLO_H
#define HELLO_H

void greeting(void);
int factorial(int);

#endif


