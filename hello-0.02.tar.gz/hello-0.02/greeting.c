
#include "hello.h"

#include <stdio.h>

void
greeting(void)
{
  printf("Hi there.\n");
}

