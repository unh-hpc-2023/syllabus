
#include <stdio.h>

#include "hello.h"

int
main(int argc, char **argv)
{
  greeting();

  printf("10 factorial is %d\n", factorial(10));

  return 0;
}

